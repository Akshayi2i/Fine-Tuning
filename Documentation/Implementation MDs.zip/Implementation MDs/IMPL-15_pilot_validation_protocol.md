# SPEC 15 — Pilot Validation Protocol (De-Risking Before Full Annotation)

> Aligned with the code at commit f5668a4 (2026-10-13).

> Read `IMPL-00_MASTER_CONTEXT.md` first. Dependencies: IMPL-01–IMPL-14 built.
>
> **This spec is executed, not imported.** It is an operational runbook, not a library — nothing else in the repo depends on it. It exists because architecture v1 added §16, which has no home in the module specs.
>
> **Architecture refs:** `finetuning-architecture-v2.3.docx` §16 (**pilot validation protocol**), §16a/§16b/§16c, §8 (pilot split ratios), §4c (day-zero bootstrap), §15 (metrics).

## Goal

Before committing to full corpus annotation, run three sequential experiments that de-risk the architecture in order of increasing investment. Each answers a different question, and each is cheap relative to the one after it.

**Run these in order. Do not skip to 16c.**

## Deliverables

### 1. `pilot/zero_shot_baseline.py` — Experiment A (Week 1, no annotation cost)

Run the **base, untuned** `Qwen3-VL-8B-Instruct` against **10 real documents per document type**, using the IMPL-01 prompt template with the Fideon SPEC_00 schema injected (for a policy, its line's canonical schema). Compute field-level F1 against ground-truth annotations.

**Implement this as a thin wrapper over the existing extraction command**, not as a parallel path. The documents are imported and OCR'd first (under their own tenant, with their labels); `extract` then reads them by source id and scores them against those labels:

```bash
python -m orchestration.run extract --model base --tenant pilot \
       --source-ids policy_0001 policy_0002 ...        # or: --split test --corpus v1
```

`pilot/zero_shot_baseline.py` holds the scoring and the decision table (`run_baseline`, `summarise_baseline`, `classify_baseline`) over `testing.run_extraction.run_document`; its own CLI only points to the extraction command (it prints the import, OCR and `extract --model base --tenant pilot --source-ids …` commands to run).

IMPL-13's `--model base` and IMPL-02's `resolve_model_version("base")` exist precisely so the baseline, day-zero pre-annotation (IMPL-04), and this experiment all run the same code. A separate implementation here would measure something subtly different from what production runs.

This tells you how much the base model extracts for free and — more usefully — **where it fails**: schema adherence, list-row recall, LoB detection, or OCR arbitration.

**Outcome thresholds and what each means:**

| Zero-shot field F1 | Interpretation | Decision |
|---|---|---|
| **> 0.70** | Strong base-model prior; fine-tuning expected to reach production quality | Proceed to pilot corpus |
| **0.40 – 0.70** | Fine-tuning will materially improve; specific failure modes identified | Proceed, **with targeted corpus coverage for the weak areas** |
| **< 0.40** | Base model likely insufficient as framed | **Review prompt design, schema complexity, and document difficulty *before* committing annotation investment** |

- Output: `pilot/reports/zero_shot_baseline.json` — per-doc-type F1, per-metric breakdown (schema validity, list recall, LoB accuracy, OCR arbitration), and the failure-mode distribution.
- Uses IMPL-07 inference core and IMPL-08 metrics — the same code the production gate uses, so the numbers are comparable later.

### 2. `pilot/smoke_test.py` — Experiment B (Weeks 1–2, 5 annotated documents)

Annotate exactly **5 documents per document type**. Train to **intentional overfit**: no train/val split, 5 epochs, learning rate at the upper end of the sweep range.

**This proves the code pipeline is correct — not that the architecture generalises.** It is a sanity check, not a proof of concept.

Confirm all of:
- Training loss reaches **below 0.05 within 2 epochs**.
- The model reproduces the 5 training examples with **field F1 > 0.95 on the training set**.
- End-to-end, without error: the ms-swift training loop, the data collator, LoRA adapter loading, adapter save and push to Azure Blob, vLLM multi-adapter hot-swap, and run manifest generation.

**Why 5 documents and not 1:** a single source document generates only three modality variants (three training examples), which isn't enough to exercise the full data collator pipeline. Five documents per type covers multi-page, OCR-failure, and image-only edge cases.

- Output: `pilot/reports/smoke_test.json` — loss curve, train-set F1, and a pass/fail per pipeline component.
- **A failure here is a code bug, not an architecture problem.** Fix it before spending annotation budget.

### 3. Experiment C — Pilot Training Run (Weeks 2–6, 25–30 documents per type)

Annotate 25–30 documents per document type per IMPL-04, using the **pilot split ratios (~70/18/12)** from IMPL-05 (or the split a delivery arrives with — master §10). Train ONE adapter for the pilot's scope with the §11.1 pilot hyperparameters (`configs/training/unified.yaml`). Evaluate on the pilot test split, in every modality regime.

This is the **minimum experiment that tests the architecture's generalisation claim**: whether one adapter captures cross-type behaviour without the types interfering, whether modality-dropout arbitration functions, whether totals reconciliation catches a missed row on unseen documents, and whether the per-field-type calibrators have enough data to be enforced at all — at pilot volume several field types will not clear the 300-instance floor and will route everything to review, which is the system working rather than failing.

**Pilot success criteria — directional targets, not production thresholds:**

| Metric | Pilot threshold |
|---|---|
| Field F1 (non-list fields) | > 0.80 |
| List-field recall | > 0.75 |
| JSON schema validity | 100% |
| Image-only field F1 | Within 15% of OCR-plus-image F1 |
| Row-completeness detection accuracy | > 80% of documents with missing rows flagged |
| LoB detection accuracy | > 0.85 (flat document types; see below for policies) |
| **Alias generalization** | Field accuracy on a **held-out surface label** within 15% of accuracy on that field's dominant label |
| **Confusable misattribution rate** | < 5% |

**LoB detection on a policy-only pilot.** A canonical policy label carries no `line_of_business` — the line comes with the request — so `lob_detection_accuracy` is structurally not applicable to policy-only scopes (`personal_lines`, `casualty_fleet`, `policy`) and the gate does not ask for it. `pilot/pilot_run.py` records it as not applicable when the pilot holds no ACORD or Loss Run documents (`Criterion.applies_to`; listed under `not_applicable` in the report), so it neither passes nor fails; for such a pilot, read it from `scripts/measure_lob_detection.py --corpus vN [--tenant T]` (the base model reading the line of each policy in the tenant's frozen eval set zero-shot, its line withheld, at serving's thresholds, against the 0.85 floor), and record that it stands in. Line detection stays off in serving until that measurement passes (master §1.3).

**A failed criterion signals a specific architectural issue to diagnose — not a reason to abandon the architecture.** Diagnose the failure-mode distribution, expand corpus coverage for the failing case, and re-run the pilot. Map each failure to its likely cause:

| Failed criterion | First place to look |
|---|---|
| Field F1 low | Prompt/schema design; corpus coverage for that doc type; LR/epochs on the unified run (a targeted retrain, not the deferred sweep) |
| List-field recall low | Loss Run corpus row-length variety; row-completeness signal (IMPL-09); consider list-specific prompt rules |
| Schema validity < 100% | Prompt rules (no fences, null-handling); JSON structural discipline in the Foundation corpus |
| Image-only F1 gap > 15% | **The ViT escalation gate (IMPL-06 `vit_gate`)** — but only if errors are perception-type, not schema/reasoning |
| Row-completeness misses | Cross-check sources in IMPL-09: is MinerU's table row count reaching the signal? |
| LoB accuracy low | **LoB corpus coverage (IMPL-05 `corpus_manifest`)** — check the ≥20%-per-value target before blaming the model. For a policy's line (the zero-shot measurement): the line meanings in `configs/lob_meanings.yaml`, and the per-line floor in the measurement's report |
| Alias generalization gap > 15% | **`alias_coverage` in the corpus manifest** — the held-out label is probably under-represented. Also check the field's semantic gloss: a vague `description` gives the model nothing to generalise from |
| Confusable misattribution ≥ 5% | **`confusable_example_count`** — near zero means the corpus taught the mapping but never the boundary. Also check the gloss carries an explicit exclusion clause (IMPL-01) |

**Alias generalization is measured by deliberate hold-out.** Pick one surface label per confusable-prone field (say, *Applicant* for `insured_name`), keep every document using it out of `train`, and place them in the pilot test split. If the model scores well on them it has learned the semantic mapping rather than memorising label strings — which is the whole claim of the canonical-field design (master §1.4) and the one thing no plumbing test can prove.

- Output: `pilot/reports/pilot_run.json` + a `pilot/pilot_report.py` summary that puts all three experiments side by side.

### 4. `pilot/pilot_report.py`
- Aggregates the three experiment reports into one human-readable go/no-go document: baseline → smoke → pilot, each with its thresholds, actuals, and pass/fail.
- States explicitly which criteria failed and the diagnosis path from the table above.
- **Every pilot training run still writes a normal `RunManifest`** (IMPL-02) — pilot runs are registry entries, not untracked experiments.
- **This is the gate the deferred work waits on.** The hyperparameter sweep (IMPL-06 `sweep.py`, arch §11a) runs *after* this protocol passes and *before* production-scale training — sweeping on 25–30 docs/type measures noise, not signal.

## Constraints
- Run the experiments **in order**; each gates the next.
- The pilot is not an exemption from the PII rules — but de-identification is currently **blocked** (IMPL-05 §1), so pilot data is protected by tenancy and access control only, and that must be acknowledged before real documents are used.
- Pilot eval numbers are **directional**. At 3–4 test documents per type, no single metric is trustworthy on its own; the batch's real job is proving the pipeline works end to end before scaling annotation to 1000+/type.
- Re-baseline properly once at real scale — do not carry pilot thresholds forward as production gates.
- Pilot documents inherit the **unresolved de-identification question** (IMPL-05 §1). Until it is resolved, pilot corpora are built without de-identification and that limitation is stated, not assumed away.

## Acceptance checklist
- [ ] `zero_shot_baseline` runs the base model over 10 docs/type and emits per-type F1 plus a failure-mode distribution.
- [ ] The baseline decision table produces the correct proceed/review recommendation on seeded scores.
- [ ] `smoke_test` trains to overfit on 5 docs/type and reports loss < 0.05 by epoch 2 and train F1 > 0.95.
- [ ] The smoke test exercises and reports pass/fail for every listed pipeline component, including Blob push and vLLM hot-swap.
- [ ] Pilot run evaluates against all eight pilot criteria (`pilot.pilot_run.PILOT_CRITERIA`) and names any that fail, or were not measured, with its diagnosis path.
- [ ] Every pilot training run produces a `RunManifest`.
- [ ] `pilot_report` renders the three experiments as one go/no-go summary.

---

## Current implementation (commit f5668a4, 2026-10-13)

- **Pilot split**: under 200 documents per type the band is 70/18/12, applied **per line of business**; a
  line with fewer than 5 documents trains whole and is not measured (listed in the manifest's
  `train_only_lines`). At pilot volume many lines fall below that — their pilot numbers do not exist, by
  design, rather than being noise.
- **A delivered split is used as given** (`split_groups.assign_delivered_splits`): the SPEC_21 delivery puts
  each seed and its twins in one split, so test layouts are ones the model never trained on, and the gate
  report adds a `real_only` section (the same metrics over the real documents alone). The per-line carrier
  hold-out is off for a delivered split; the CGL bundler marks a test document of a carrier no training
  document has as `held_out_carrier`, and evaluation reports such documents apart (`held_out_carrier_match`,
  not gated).
- **Alias hold-out** (above) is still done by choosing documents deliberately; it is not automatic — the
  hash split does not know which surface label to hold out. For common-model lines,
  `scripts/check_alias_coverage.py` lists the recorded labels no training document prints, and evaluation
  splits field accuracy into labels training showed and labels it never did (`unseen_labels`, reported).
- **Freezing a pilot eval set** is per tenant: `freeze-eval-set --corpus vN [--tenant T]` writes
  `golden-eval-set/{tenant}/`, and needs `--allow-small` under 150 test documents per type: the set is then
  directional, and once frozen it is the yardstick for every later version of that tenant. Prefer to freeze
  from the first build at real scale; if a pilot set is frozen, replacing it later is a deliberate
  delete-and-refreeze after which older scores are not comparable.
- **A pilot whose eval set holds no scans** (the CGL originals are all digital) is not blocked on
  `scanned_accuracy`: it is a conditional gate metric, required only when the eval set holds scanned documents
  — and required whenever the frozen baseline measured it, since its absence then means something broke.
- **Pilots by scope and tenant**: `personal_lines` trains on the SPEC_21 personal-lines delivery;
  `casualty_fleet` trains on the CGL documents alone (`gl`, real documents, no twins), in their own tenant,
  bundled with `python -m data_pipeline.ingestion.prepare_bundles --input <PDFs/ + Gold JSON/> --lob gl --out <dir>`
  (`cgl` reads as `gl`; one family per insured; split drawn once and delivered in the metadata). Each tenant has its
  own corpus, frozen set and releases.
- **Before the pilot's `finetune`**: `python -m data_pipeline.ocr_check` (labelled values against the OCR
  text), `python -m orchestration.preflight --scope <scope>` (add `--skip-corpus` when `finetune` follows in the
  same chain: the build then runs once, and refuses a >25% set-aside itself), and
  `python -m orchestration.smoke_run --scope <scope>` (tenant `smoke`, version `v0`, 4 train / 1 val / 1 test
  sources with their twins; never freezes or packages). The smoke run proves the plumbing; it is not
  Experiment B.
- **Reading the results**: `extract` writes per-document JSON (with `all_fields`: every schema field, its value
  and its result against gold) and metrics; `python -m testing.compare_models` runs the same documents through
  the base model and base + adapter and writes both, with a workbook per document. Every stage of a run records
  its wall time in `run-<command>-<scope>-<tenant>-<version>.json` under `/workspace/logs`.
- **Pod runs**: every pilot command started on the pod runs detached in tmux (IMPL-13); install each pod with
  `bash scripts/pod_bootstrap.sh` (both environments, MinerU 3.4.5's pinned pipeline weights, the base model
  and the spike), and run OCR in `/workspace/venv-ocr` (MinerU 3.4.5, pipeline backend) before any pipeline
  command. A corpus read by two MinerU versions is refused, so documents read under MinerU 1.x are re-read
  first (`run_mineru --all-unprocessed`).

## Changes since 2026-10-05

- Added the alignment line.
- Experiment A: the extraction command as it exists (`--tenant`, `--source-ids` or `--split`/`--corpus`, documents imported and OCR'd first); where the baseline's scoring lives, and that its CLI hint is stale.
- Experiment C: one adapter per pilot scope; a delivered split may replace the drawn one.
- Criteria: LoB detection is not applicable to policy-only scopes; how to stand in `scripts/measure_lob_detection.py` for it, and that `pilot_run` records it as not applicable; diagnosis row for a policy's line.
- Acceptance: eight criteria, not six.
- Current implementation: delivered split and held-out carriers, alias coverage for common-model lines, per-tenant freeze, conditional `scanned_accuracy`, the `personal_lines` and `casualty_fleet` pilots, the pre-`finetune` checks (OCR check, preflight `--skip-corpus`, smoke run), result tools (`all_fields`, `compare_models`, run report), and MinerU 3.4.5 on the pod.
- `pilot_run` records a criterion the pilot's document types cannot measure as not applicable, and the zero-shot baseline prints the current commands (commit f5668a4).
